import logging
import random
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

TOKEN = "7872696744:AAHQ65h0Eyknj15Lb1TFGpnl0WE1NyAyuk"
CHAT_ID = None  # Réglé dynamiquement

# Historique des prédictions
predictions = []

logging.basicConfig(level=logging.INFO)

# Simulation simple d'un système de prédiction (remplace par ton algo)
def generate_prediction():
    predicted = round(random.uniform(1.5, 3.0), 2)
    actual = round(random.uniform(1.0, 5.0), 2)
    return predicted, actual

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global CHAT_ID
    CHAT_ID = update.effective_chat.id
    await update.message.reply_text("Bienvenue dans Chinwa Crash Bot ! Tape /predict pour commencer.")

async def predict(update: Update, context: ContextTypes.DEFAULT_TYPE):
    predicted, actual = generate_prediction()
    success = actual >= predicted
    predictions.append({
        "predicted": predicted,
        "actual": actual,
        "success": success
    })
    if len(predictions) > 10:
        predictions.pop(0)
    message = f"Prédiction : x{predicted}\nMultiplicateur réel : x{actual}\nSuccès : {'Oui' if success else 'Non'}"
    await update.message.reply_text(message)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not predictions:
        await update.message.reply_text("Aucune prédiction encore.")
        return
    lines = []
    correct = 0
    for i, p in enumerate(predictions[-10:][::-1], 1):
        line = f"{i}. x{p['predicted']} -> x{p['actual']} ({'OK' if p['success'] else 'Raté'})"
        lines.append(line)
        if p['success']:
            correct += 1
    pourcentage = (correct / len(predictions)) * 100
    await update.message.reply_text("\n".join(lines) + f"\nTaux de réussite : {pourcentage:.1f}%")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("predict", predict))
    app.add_handler(CommandHandler("stats", stats))
    print("Bot démarré...")
    app.run_polling()
